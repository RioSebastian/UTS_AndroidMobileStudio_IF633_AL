package umn.ac.id.uts_26656;

import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
public class MusicList extends
        RecyclerView.Adapter<MusicList.MusicViewHolder> {
    @NonNull
    @Override
    public MusicList.MusicViewHolder onCreateViewHolder
            (@NonNull ViewGroup parent, int viewType) {
        return null;
    }
    @Override
    public void onBindViewHolder
            (@NonNull MusicList.MusicViewHolder holder,
             int position) {
    }
    @Override
    public int getItemCount() {
        return 0;
    }
}